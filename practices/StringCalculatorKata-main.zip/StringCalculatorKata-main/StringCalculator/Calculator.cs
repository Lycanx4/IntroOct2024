﻿
public class Calculator
{
    public int Add(string numbers)
    {
        return -42;
    }
}
